Simulador MATLAB del curso Robotica Movil, FIUBA 2020

El script robot_diffdrive_LidarSensor.m tiene el simulador de robot diferencial.
Es compatible con MATLAB R2020a y con MATLAB 2016b. No es compatible con versiones anteriores a R2016b y seguramente es compatible con versiones posteriores a R2016b, pero no fue verificado.

El script debe usarse como template para desarrollar el trabajo ya que luego cambiando el valor de use_roomba a true puede usarse con el robot real.

Tener en cuenta que nuevas versiones de este simulador pueden llegar a ser publicadas por lo que se recomienda el uso modular que permita actualizar el simulador facilmente.

IM
